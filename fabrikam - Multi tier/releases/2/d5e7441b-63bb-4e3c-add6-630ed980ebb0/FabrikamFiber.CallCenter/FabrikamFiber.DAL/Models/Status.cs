﻿namespace FabrikamFiber.DAL.Models
{
    public enum Status
    {
        Open,
        Closed,
        Pending,
        Assigned
    }
}
